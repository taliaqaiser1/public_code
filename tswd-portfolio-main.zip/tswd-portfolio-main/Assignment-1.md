## In-class exercise: COVID-19 Cases
<div class="flourish-embed flourish-chart" data-src="visualisation/14926892"><script src="https://public.flourish.studio/resources/embed.js"></script></div>

