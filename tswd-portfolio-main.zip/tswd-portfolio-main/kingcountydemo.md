# In-class Data Visualization
### Used Flourish.studio 

<div class="flourish-embed flourish-chart" data-src="visualisation/14926892"><script src="https://public.flourish.studio/resources/embed.js"></script></div>
