[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-8d59dc4de5201274e310e4c54b9627a8934c3b88527886e3b421487c677d23eb.svg)](https://classroom.github.com/a/Hf055y1F)
# Final Project - Data Cleaning
### Machine Learning Foundations with Python (90-803)
#### Spring 2023


**DUE DATE: Thursday, March 30th, 2023 before 11:59 PM**


---

Please read the following instructions carefully and do one submission per team!

Same as in Lab 8, make sure to join this submission as a team. In this case name your teams as follows: `team#_initalsMember1_initalsMember2_initalsMember3`

- For example: If I'm team 1 (on Canvas) and my initials are `GGS`, and my team member 2's initials are `JF`, we would name our group for this assignment: `team1_GGS_JF`.

**Remember that one of you has to create the team name on GitHub classroom and then the rest of you must join the same team**

---

### Tasks To Do

For this delivery, you must dive deeper into your datasets, by performing three main tasks:

1. Reading and Cleaning your dataset/s 

	- Explore if your dataset/s has NAs and deal with them (or provide an explanation for keeping them and how you will deal with them moving forward)
	- If you are doing a classifier take note of how many data points per class you have (and what are you going to do with them).
	- Any other necessary conversation such as dealing with categorical variables, verifying each variable is the right type.
	-  If you have more than one dataset make sure to clean ALL of your datasets!

2. Decide whether you are merging your datasets or keeping them separate.
	- If you are keeping your datasets separate provide a brief explanation of how you are going to use each dataset.
	- If you are joining your datasets check that you are not losing relevant data and you are joining your dataset correctly.

3. Provide at least two initial visualizations that describe your data. These can be a correlation plot of all the variables, a boxplot or density plots of the variables, or even a plot specific to any of the questions you are trying to tackle.

4. Define your classification or prediction variables (or none if you're doing unsupervised learning). 

5. Refine the 2-3 questions you want to answer with your datasets (based on the feedback you received from your previous assignment)

6. Do a pre-liminary test. Train a model (prediction or classification) with your clean dataset. Report how good is this initial test. You only need to do this for one of your questions.



The idea - by the end of this delivery - is to have a clean source of data that the whole team can use moving forward. If you discover you don't have enough data or the specific problem you choose is not enough for modeling then use this assignment to change your topic and datasets. You still need to submit a cleaned dataset by the end of this assignment.

---

### Submission

- Include your Jupyter Notebook/s in this repo
- Include your data inside the `data` folder
- Modify the last section of this README to include your revised questions and any additional instructions.

In each Jupyter notebook include:

- The class and assignment (first cell)
- The name of your team (first cell)
- The full names of your teammates (first cell)
- Explanations where needed for your tasks. Include enough comments and markdown cells for use to follow your cleaning process.
- Remember to only use packages we have seen in this class (or 90-800)
- A section with References at the end of the notebook


### Warnings (read carefully):

- You will receive 0 points if you do not submit your Jupyter notebook (.ipynb) and/or I'm not able to run it.
- List any references you used, even if they are one of the books assigned for this class. If this section is incomplete you will be deducted 30% of your final grade.
- If there are no comments to explain your code you will receive 0 in this assignment.

---

### Revised Questions - Please fill in

1. How effectively can we cluster songs together based on common characteristics? This is to reduce the amount of genres that we feed into the next step while providing users with genres similar to the ones they enjoy. (Using K-Means clustering, Hierarchical clustering unsupervised learning)
- For this question, since we will be using unsupervised learning, we do not have classification or prediction variables. 

2. How well can we predict song genres based on spotify metadata? (random forest, logistic regression, KNN, naive bayes using supervised learning)
- For this question, our classification variable is genre.

3. To what extent can we predict the popularity of a song based on its metadata (tempo, valence, danceability, etc..)? (Using supervised learning techniques such as linear and polynomial regression, random forest )
- For this question, our prediction variable is popularity. 

---

### Notes - Please fill in

### Datasets can be found on Google Drive: https://drive.google.com/drive/folders/1pefnNk1ntP3Fjtd_mwC3mKzEfL5ryzG7?usp=sharing

### Relevant datasets

#### audio_features_4.0_clean.csv
- This csv file contains ~600,000 tracks with associated genre information and audio features. For some songs, popularity is included as well.

#### spotify_genres.txt
- This is a list of all the genres recognized by Spotify, separated by \n characters.

#### selected_genres.txt
- This is the list of genres we chose to focus on for our analysis. These are the genres that emerged in our initial scraping as having fewer limits on the available number of tracks.

### Description of files in our repo

#### For the April 4th submission, these two files are most relevant. 

#### track_cleaning.ipynb
- To run this file, you'll need the audio_features_4.0.csv file from Google Drive. This file can be reproduced using the get_song_stats file (it takes a very long time to download all the data). The default path is data/audio_features_4.0_clean.csv in the local directory.
- This file shows the thought process behind the way we chose to clean our data, and the different issues we checked for as we went.
- At the end of the notebook, it outputs a new csv labeled audio_features_4.0_clean.csv with the modifications specified in the notebook. This is the csv we used for modeling.
- After choosing a k using the elbow method, and fixing class imbalances, the file tries a variety of models as our first attempt at classifying the data into different genres. This also sheds light on our efforts to group songs together based purely on features (using unsupervised learning/clustering).


#### audio_features_modeling_clusters.ipynb
- This file is our initial attempt at modeling our data.
- It takes audio_features_4.0_clean.csv as an input file.
- Overall, our dataset had 132 genres. Because our early classification models struggled to predict this many genres, we decided to aggregate them. The binning process, which uses KMeans clustering, occurs in the first part of this file.

#### We also provide additional files, which reproduce the process of collecting our dataset from the Spotify API. These files take several days to run, and require you to sign up for an app through the Spotify API.

#### get_song_stats.ipynb
- This file takes a .txt file of genres separated by \n as an input. In our case, we used selected_genres.txt, which is provided in the data directory in our repo. 
- The file requires a client_secret and client_id from the Spotify API, which requires a Spotify account.
- When you run the file, it goes genre-by-genre and downloads the 1000 top artists (or however many are available), gets the top 10 songs from those artists, and then gets the features from these songs. 
- It stores this data in a sqlite3 database file called song_data_2.0.db, which can be found on Google Drive. This file is not necessary to run the other notebooks above, which take a csv version.
- At the end of this notebook, there is a cell which exports the database as a csv.

#### get_popularity.ipynb
- This file allowed us to get popularity data for a subset of our songs, to answer our research question about whether or not song features predict popularity.
- It requires access to a sqlite3 file that is already populated with audio features. After get_song_data is finished running, this file can be run on the same database. 
- This file also requires a client secret and client id from Spotify, or a one-time access token from Spotify. 









In this section, include any last clarification notes about your project.
- If you have more than one notebook include instructions as to how to run them (in which order) and a brief description of what each notebook has.

